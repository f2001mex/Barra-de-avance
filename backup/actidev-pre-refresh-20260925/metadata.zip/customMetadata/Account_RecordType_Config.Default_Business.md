<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>Default Business</label>
    <protected>false</protected>
    <values>
        <field>Key__c</field>
        <value xsi:type="xsd:string">DEFAULT_BUSINESS</value>
    </values>
    <values>
        <field>RecordTypeDeveloperName__c</field>
        <value xsi:type="xsd:string">Cuentas_empresariales</value>
    </values>
</CustomMetadata>
